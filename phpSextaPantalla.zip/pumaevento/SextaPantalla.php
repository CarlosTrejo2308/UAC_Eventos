<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1" charset="UTF-8">
<head>
<title>Puma Calendar</title>   
<link rel="stylesheet" href="./css/estiloSextaPantalla.css">
</head>

<body>
<div class="div1">
    <img class="img1" src="./img/logoSistemas.jpg" alt="Mountain View">
</div>

<div class="div2">
<h1>Facultad de Sistemas</h1>
</div>

<!-- menú -->
<div class="div menu">
<ul>
  <li><a href="#home"> Inicio </a></li>
  <li><a href="#eventos"> Eventos </a></li>
  <li><a href="#configuracion"> Configuracion </a></li>
</ul>
</div>

<div class="div4">
<p class="p1">
Nombre Evento
</p>
</div>

<!-- caja para fecha -->
<div class="div5">
<p class="p2"> /	/ </p>
</div>

<div class="div6">
    <img class="img2" src="./img/ImagenCalendario.png" alt="Imagen Calendario" width="35" height="35" align="right">

</div>

<div class="div7">
<p class="p3">
Descripción del evento ya creado
</p>
</div>

<div class="div8-button-group">
<input class="boton1" type="button" name="botonAsistire" value="Asistiré">
<input class="boton2" type="button" name="botonTalvezAsista" value="Talvez Asista">
</div>

<div class="div9">
<p class="p4">
Ubicación
</p>
</div>

<div class="div10">
<p class="p5"> Foto del evento </p>
</div>

<div class="div11map"></div>

<script>
function myMap() {
var mapOptions = {
    center: new google.maps.LatLng(51.5, -0.12),
    zoom: 15,
    mapTypeId: google.maps.MapTypeId.ROADMAP
}
var map = new google.maps.Map(document.getElementById("map"), mapOptions);
}
</script>

<script src="paginaweb"></script>
</body>
</html>