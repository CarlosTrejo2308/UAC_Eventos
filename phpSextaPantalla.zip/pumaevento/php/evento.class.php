<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Description of evento
 *
 * @author ELVIRA
 */
include 'db_connection.php';

class evento {
    
    public function __construct() {      
    }
    
    public function evento(){
         openDBCnx();
    global $coneccion;
    
    $nomEve = "SELECT NOMBRE_EVENTO FROM eventos WHERE ID_EVENTO = '".$idEvento."'";
    $resultado = mysqli_query($coneccion, $nomEve);    
    if ($row = mysqli_fetch_row($resultado)){
        
    }
    }
    
    public function fecha(){
         openDBCnx();
    global $coneccion;
    
    $fechaEve = "SELECT FECHA FROM eventos WHERE ID_EVENTO = '".$idEvento."'";
    $resultado = mysqli_query($coneccion, $fechaEve);
    if (mysqli_num_rows($resultado) > 0) {
            $arreglo = mysqli_fetch_all($resultado);
    }
    }
    
     public function descripcion(){
        openDBCnx();
    global $coneccion;
    
    $descripEve = "SELECT DESCRIPCION FROM eventos WHERE ID_EVENTO = '".$idEvento."'";
    $resultado = mysqli_query($coneccion, $descripEve);    
    if (mysqli_num_rows($resultado) > 0) {
            $arreglo = mysqli_fetch_all($resultado);
    }
     }
    
    public function ubicacion(){
        openDBCnx();
    global $coneccion;
    
    $ubicaEve = "SELECT UBICACION FROM eventos WHERE ID_EVENTO = '".$idEvento."'";
    $resultado = mysqli_query($coneccion, $ubicaEve);  
    if (mysqli_num_rows($resultado) > 0) {
            $arreglo = mysqli_fetch_all($resultado);
    }
    }
    
    public function imagenEvento(){
        openDBCnx();
    global $coneccion;
    
    $imgEve = "SELECT FOTOS FROM eventos WHERE ID_EVENTO = '".$idEvento."'";
    $resultado = mysqli_query($coneccion, $imgEve); 
    if (mysqli_num_rows($resultado) > 0) {
            $arreglo = mysqli_fetch_all($resultado);
            
    }
            
    
    }
    
    
        
}
