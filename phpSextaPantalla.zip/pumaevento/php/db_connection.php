<?php

    function openDBCnx () {
        
        global $coneccion;

        // 1. Create a database connection
        $coneccion = mysqli_connect("localhost", "root", "", "pumaeventos");
        // Test if connection succeeded
        if(mysqli_connect_errno()) {
          die("Database connection failed: " . 
               mysqli_connect_error() . 
               " (" . mysqli_connect_errno() . ")"
              );
        } 
        
        if (!mysqli_set_charset($coneccion, "utf8")) {
           printf("Error loading character set utf8: %s\n", mysqli_error($coneccion));
            exit();
        } else {
            //printf("Current character set: %s\n", mysqli_character_set_name($connection));
        }
    }
?>
