<html>
   <meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<title>Crear Evento.</title>   
<link rel="stylesheet" href="estiloQuintaPantalla.css">
</head>

<body>
<div class="div1">
<img src="logoSistemas.jpg" alt="Logo de Sistemas">
</div>

<div class="div2">
<h1>Facultad de Sistemas</h1>
</div>

<nav class="nav">
<ul>
    <li><a href="index.php">Inicio</a></li>
<li><a href="lista_eventos.php">Eventos</a></li>
<li><a href="configuracion.php">Configuracion</a></li>
</ul>

<div class="div3">
<h2>Esta es la pagina para crear eventos.</h2>
</div>

</body>
</html>
