<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
   <meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<title>Welcome Admin.</title>   
<link rel="stylesheet" href="estiloQuintaPantalla.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>

<body>
<div class="div1">
<img src="logoSistemas.jpg" alt="Logo de Sistemas">
</div>

<div class="div2">
<h1>Facultad de Sistemas</h1>
</div>

<nav class="nav">
<ul>
    <li><a href="index.php">Inicio</a></li>
<li><a href="lista_eventos.php">Eventos</a></li>
<li><a href="configuracion.php">Configuracion</a></li>
</ul>

<div class="div3">
<h2>Welcome Admin.</h2>
<p class="p1">
Bienvenidos a "Puma Calendar" la pagina web informativa sobre los
proximos eventos de la facultad de Sistemas y la UAdeC.
Estos son los eventos mas recientes del mes de:
<script>
var meses= new Array ("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
var f=new Date();
document.write(meses[f.getMonth()] + " del  " + f.getFullYear());
</script>
</p>
</div>

<div class="div35">
<i class="material-icons" style="font-size:24px;">search</i>
</div>

<div class="div4">
<form method="get" action="search.php">
<input type="search" name="q" placeholder="Buscar evento" required="required"/>
<input type="submit" id="x" name="Buscar" value="Buscar">
</form>
</div>

<div class="div5">
<p class="p1">Cantidad total de usuarios registrados:
<?php
$conexion = mysqli_connect("localhost","root",null);
mysqli_select_db($conexion, "PumaEventos01");
$tildes = $conexion->query("SET NAMES 'utf8'"); //Para que se muestren las tildes
$result = mysqli_query($conexion, "SELECT COUNT(*) AS total FROM usuarios");
$row = mysqli_fetch_array($result);
$count = $row['total'];
echo "$count usuarios";
mysqli_close($conexion);
?>
</p>
<p class="p1">Contador de visitas:
<?php
$a= file("contador.DATA");
$b= $a[0];
if($_COOKIE['conteo']==1){
    echo "$b visitas";
}
else{
  $b= $b + 1;
$conteo= fopen("contador.DATA","w");
fwrite($conteo, $b);
fclose($conteo);
setcookie("conteo","1");
echo "$b visitas";
}
?>
</p>
</div>

<div class="div6">
    <a href="lista_usuarios.php"><input type="button" name="VerUsuarios" value="Ver Usuarios" ></a>
</div>

<div class="div7">
    <a href="crear_evento.php"><input type="button" name="CrearNuevoEvento" value="Crear Nuevo Evento"></a>
</div>

<div class="div8">
    <a href="lista_eventos.php"><input type="button" name="ListadodeEventos" value="Listado de Eventos"></a>
</div>

<div class="dropdown">
<img src="ImagenCalendario.png" alt="Icono Calendario" width="1%" height="1%">
<select name="Listado de meses">
   <option select value="0">Listado de meses</option> 
   <option value="1">Enero</option> 
   <option value="2">Febrero</option>
   <option value="3">Marzo</option> 
   <option value="4">Abril</option> 
   <option value="5">Mayo</option>
   <option value="6">Junio</option> 
   <option value="7">Julio</option>
   <option value="8">Agosto</option> 
   <option value="9">Septiembre</option> 
   <option value="10">Octubre</option> 
   <option value="11">Noviembre</option> 
   <option value="12">Diciembre</option> 
</select>
</div>

<div class="div9">
<script>
var meses = new Array ("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
var diasSemana = new Array("Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado");
var f=new Date();
document.write(diasSemana[f.getDay()] + ", " + f.getDate() + " de " + meses[f.getMonth()] + " de " + f.getFullYear());
</script>
</div>

<div class="div10">
<img src="muymal.jpg">
</div>
<div class="div11">
<textarea class="a1" rows="5"cols="50"></textarea>
</div>

</body>
</html>