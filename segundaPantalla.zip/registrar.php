<?php
include ("usuario.class");

$nombre = '';
if(isset($_POST['fname'])){
    $nombre = $_POST['fname']; 
}

$apellido = '';
if(isset($_POST['lname'])){
    $apellido = $_POST['lname'];
}

$carrera = '';
if(isset($_POST['subject'])){
    $carrera = $_POST['subject'];
}

$correo = '';
if(isset($_POST['email'])){
    $correo = $_POST['email'];
}

$contrasena = '';
if(isset($_POST['pass1'])){
    $contrasena = $_POST['pass1'];
}

$foto = '';
if(isset($_POST['Foto'])){
    $foto = $_POST['Foto'];
}

$ev = new usuario();
$ev->nombre = $nombre;
$ev->apellido = $apellido;
$ev->carrera = $carrera;
$ev->correo = $correo;
$ev->contrasena = $contrasena;
$ev->foto = $foto;

$r = $ev->registrar();
echo $r;
?>

<form action="TerceraPantalla.php" method="POST">
    <input type="submit" value="Ir al inicio" />
</form>

<form action="segundaPantalla.php" method="POST">
    <input type="submit" value="Volver al formulario" />
</form>

