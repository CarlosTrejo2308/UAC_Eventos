<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
	<title>Registro</title>
	<link rel="stylesheet" href="estiloSegundaPantalla.css">
</head>
<body>
	<div class="div1">
		<img src="logoSistemas.jpg" alt="Mountain View">
	</div>
	<div class="div2">
		<h1>Facultad de Sistemas</h1>
	</div>
	<div class="div3">
		<p class='P1'>
			Foto de Perfil
		</p>
	</div>
	<div class="div4">
		<!--Aqui va la foto de perfil-->
                <img id="perfil" src="default_foto.jpg" alt="Foto Perfil"><br><br>
<input class="bot4" type="file" name="Foto" value="Ingresa Foto de Perfil">
	</div>
    <form action="registrar.php" method="POST"  NAME="form">
      <div class="div5">
          <input type="text" id="fname" name="fname" placeholder="Nombre" required><br><br>
  <script>
      function checkname(){
    var textbox = document.getElementById("fname");
    if(textbox.value.length >= 20){
        alert("Nombre debe ser menor a 20 caracteres")
    }
}
      </script>
      <input type="text" id="lname" name="lname" placeholder="Apellido"  required><br><br>
  <script>
      function checklastname(){
    var textbox = document.getElementById("lname");
    if(textbox.value.length >= 20){
        alert("Apellido debe ser menor a 20 caracteres")
    }
}
      </script>
      <input type="text" id="subject" name="subject" placeholder="Carrera"  required><br><br>
  <script>
      function checksubject(){
    var textbox = document.getElementById("subject");
    if(textbox.value.length >= 5){
        alert("Carrera debe ser menor a 5 caracteres")
    }
}
      </script>
      <input type="text" id="email" name="email" placeholder="Correo institucional" required><br><br>
  <script>
      function checkemail(){
    var textbox = document.getElementById("email");
    if(textbox.value.length >= 35){
        alert("Email debe ser menor a 35 caracteres")
    }
}
      </script>
      <input type="password" id="pass1" name="pass1" placeholder="Contrasena" required><br><br>
  <script>
      function checkcontrasena(){
    var textbox = document.getElementById("pass1");
    if(textbox.value.length >= 30){
        alert("Contraseña debe ser menor a 30 caracteres")
    }
}
      </script>
<input id="button" type="submit"  name = "submit" value="Registrar" onclick="checkname(),checklastname(),checksubject(),
       checkemail(),checkcontrasena()">
	</div>
</form>
	<div class="div6">
		<p class='p1'>
			Para registrarte en "Puma Calendar" es necesario que cuentes con un correo institucional proporcionado por la UAdeC
		</p>
	</div>
</body>
</html>