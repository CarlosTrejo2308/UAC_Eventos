<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
   <meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<title>Welcome Admin.</title>   
<link rel="stylesheet" href="estiloQuintaPantalla.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>

<body>
<div class="div1">
    <img id="logo" src="logoSistemas.jpg" alt="Logo de Sistemas">
</div>

<div class="div2">
<h1>Facultad de Sistemas</h1>
</div>

<nav class="nav">
<ul>
    <li><a href="QuintaPantalla.php">Inicio</a></li>
    <li><a href="SeptimaPantalla.php">Eventos</a></li>
<li><a href="configuracion.php">Configuracion</a></li>
</ul>

<div class="div3">
<h2>Welcome Admin.</h2>
<p class="p1">
Bienvenidos a "Puma Calendar" la pagina web informativa sobre los
proximos eventos de la facultad de Sistemas y la UAdeC.
Estos son los eventos mas recientes del mes de:
<script>
var meses= new Array ("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
var f=new Date();
document.write(meses[f.getMonth()] + " del  " + f.getFullYear());
</script>
</p>
</div>

<div class="div35">
<i class="material-icons" style="font-size:24px;">search</i>
</div>

<div class="div4">
<form action="Nombre_evento.php" method="POST">
    <input type="text" class="form-control" name="codigo" placeholder="Buscar evento" required>
        <input type="submit" id="name" value="Buscar">
     </form>
</div>

<div class="div5">
<p class="p1">Cantidad total de usuarios registrados:
<?php
include("conexion.php");
$tildes = $conexion->query("SET NAMES 'utf8'"); //Para que se muestren las tildes
$result = mysqli_query($conexion, "SELECT COUNT(*) AS total FROM usuarios");
$row = mysqli_fetch_array($result);
$count = $row['total'];
echo "$count usuarios";
mysqli_close($conexion);
?>
</p>
<p class="p1">Contador de visitas:
<?php
$a= file("contador.DATA");
$b= $a[0];
if($_COOKIE['conteo']==1){
    echo "$b visitas";
}
else{
  $b= $b + 1;
$conteo= fopen("contador.DATA","w");
fwrite($conteo, $b);
fclose($conteo);
setcookie("conteo","1");
echo "$b visitas";
}
?>
</p>
</div>

<div class="div6">
    <a href="OctavaPantalla2.php"><input type="button" name="VerUsuarios" value="Ver Usuarios" ></a>
</div>

<div class="div7">
    <a href="crear_evento.php"><input type="button" name="CrearNuevoEvento" value="Crear Nuevo Evento"></a>
</div>

<div class="div8">
    <a href="SeptimaPantalla.php"><input type="button" name="ListadodeEventos" value="Listado de Eventos"></a>
</div>
    
<div class="div9">
       <?php
include("conexion.php");
?>	
<table border="1" >
		<tr>
                        <td>FOTO DEL EVENTO</td>	
			<td>NOMBRE DEL EVENTO</td>
			<td>DESCRIPCION</td>
			<td>UBICACION</td>
                        <td>FECHA</td>
		</tr>

		<?php 
		$sql="SELECT * FROM eventos WHERE FECHA BETWEEN NOW() and '2017-11-31'";
		$result=mysqli_query($conexion,$sql);
		while($mostrar=mysqli_fetch_array($result)){
		 ?>

		<tr>
                    <td><?php $foto=$mostrar["FOTOS"];
                    echo "<img src='data:image/jpge; base64," . base64_encode($foto). "'>";?></td>
			<td><?php echo $mostrar['NOMBRE_EVENTO'] ?></td>
			<td><?php echo $mostrar['DESCRIPCION'] ?></td>
			<td><?php echo $mostrar['UBICACION'] ?></td>
			<td><?php echo $mostrar['FECHA'] ?></td>
		</tr>
	<?php 
	}
        mysqli_close($conexion);
	 ?>
	</table>
</div>
</body>
</html>