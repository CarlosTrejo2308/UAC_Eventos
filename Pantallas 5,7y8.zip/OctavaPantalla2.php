<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<title>Lista de Usuarios</title>

<title>Lista de Usuarios</title>   
<link rel="stylesheet" href="EstiloOctavaPantalla.css">
</head>

<body>
<div class="div1">
<img id="logo" src="logoSistemas.jpg" alt="Mountain View">
</div>

<div class="div2">
<h1>Facultad de Sistemas</h1>
</div>

<nav class="nav">
<ul>
    <li><a href="QuintaPantalla.php">Inicio</a></li>
<li><a href="SeptimaPantalla.php">Eventos</a></li>
<li><a href="configuracion.php">Configuracion</a></li>
</ul>

<div class="div4">
<p class="p1">
Numero de usuarios registrados en la plataforma:
<?php
include("conexion.php");
$tildes = $conexion->query("SET NAMES 'utf8'"); //Para que se muestren las tildes
$result = mysqli_query($conexion, "SELECT COUNT(*) AS total FROM usuarios");
$row = mysqli_fetch_array($result);
$count = $row['total'];
echo "$count";
mysqli_close($conexion);
?>
</p>
<p class="p1">
Esta es la lista de usuarios registrados en la plataforma:
</p>
</div>

<div class="div5">
<?php
include("conexion.php");
?>	
<table border="1" >
		<tr>
                        <td>"FOTO DE PERFIL"</td>	
			<td>NOMBRES</td>
			<td>APELLIDOS</td>
			<td>CARRERA</td>
                        <td>CORREO</td>
		</tr>

		<?php 
		$sql="SELECT * from usuarios";
		$result=mysqli_query($conexion,$sql);
		while($mostrar=mysqli_fetch_array($result)){
		 ?>

		<tr>
                    <td><?php $foto=$mostrar["FOTO_PERFIL"];
                        echo "<img src='data:image/jpge; base64," . base64_encode($foto). "'>";?></td>
			<td><?php echo $mostrar['NOMBRES'] ?></td>
			<td><?php echo $mostrar['APELLIDOS'] ?></td>
			<td><?php echo $mostrar['CARRERA'] ?></td>
			<td><?php echo $mostrar['CORREO_INST'] ?></td>
		</tr>
	<?php 
	}
	 ?>
	</table>
</div>

</body>
</html>
