<?php
$host="localhost";
$user="root";
$pw=null;
$bd="PumaEventos01";
$conexion= mysqli_connect($host, $user, $pw) or die ("Error al conectar al servidor");
mysqli_select_db($conexion,$bd);
?>

