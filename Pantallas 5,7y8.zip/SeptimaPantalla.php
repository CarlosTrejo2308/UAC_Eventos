<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <head>
 <link  href="estiloseptimapantalla.css" rel="stylesheet">
  <title>Lista de Eventos</title>
 </head>
 <body>

<div class="div1">
    <img id="logo" src="logoSistemas.jpg" alt="logo">
</div>

<div class="div2">
<h1>Facultad de Sistemas</h1>
</div>
<div class="div4">
<ul>
    <li><a href="QuintaPantalla.php">Inicio</a></li>
    <li><a href="SeptimaPantalla.php">Eventos</a></li>
<li><a href="configuracion.php">Configuracion</a></li>
</ul>
</div>
<div class="div3">
<p class="p1">
Esta es la lista total de los eventos registrados:
</p>
</div>

<div class="div45">
<form action="Nombre_evento.php" method="POST">
    <input type="text" class="form-control" name="codigo" placeholder="Buscar evento" required>
        <input type="submit" id="name" value="Buscar">
     </form>
</div>
     
<div class="div455">
    <img id="lupa" src="lupita.jpg" alt="Buscar Evento">
</div>

<div class="div75">
    <img id="calendario" src="calendario.png" alt="Buscar Evento">
</div>

<div class="div5">
  <?php
include("conexion.php");
?>	
<table border="1" >
		<tr>
                        <td>FOTO DEL EVENTO</td>	
			<td>NOMBRE DEL EVENTO</td>
			<td>DESCRIPCION</td>
			<td>UBICACION</td>
                        <td>FECHA</td>
		</tr>

		<?php 
		$sql="SELECT * from eventos";
		$result=mysqli_query($conexion,$sql);
		while($mostrar=mysqli_fetch_array($result)){
		 ?>

		<tr>
                    <td><?php $foto=$mostrar["FOTOS"];
                        echo "<img src='data:image/jpge; base64," . base64_encode($foto). "'>";?></td>
			<td><?php echo $mostrar['NOMBRE_EVENTO'] ?></td>
			<td><?php echo $mostrar['DESCRIPCION'] ?></td>
			<td><?php echo $mostrar['UBICACION'] ?></td>
			<td><?php echo $mostrar['FECHA'] ?></td>
		</tr>
	<?php 
	}
	 ?>
	</table>
    
 </div>
     
</body>
</html>